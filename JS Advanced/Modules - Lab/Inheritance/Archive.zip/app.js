result.Entity = require('./Entity');
result.Dog = require('./Dog');
result.Person = require('./Person');
result.Student = require('./Student');